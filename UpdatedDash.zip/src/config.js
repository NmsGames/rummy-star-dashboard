// export const apiBaseURL = "http://ec2-3-109-71-196.ap-south-1.compute.amazonaws.com:5000";
 export const apiBaseURL = "http://localhost:5000";
//  const apiBaseURL = "http://15.207.171.247:5000";
// const data      = JSON.parse(sessionStorage.getItem('token')); 
// export const authToken = data.token;
// export const user = data.user;
 
 