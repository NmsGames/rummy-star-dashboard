 
import 'bootstrap/dist/css/bootstrap.min.css';
import '../src/style/singup.css';
import { BrowserRouter as Router, Switch, Route } from 'react-router-dom'
import React from 'react';
import Login from "./components/Login" 
import Dashboard from './components/Dashboard/Dashboard'
import DashBody from './components/Dashboard/DashBody' 
// rummy-start 
import CreateAgent from "./components/extrapages/AddAgent";
import AddPlayer from "./components/extrapages/AddPlayer";
import ChangePassword from "./components/extrapages/ChangePassword"; 
import IdChangePassword from "./components/extrapages/IdChangePassword"; 
import PlayerTransferPoints from "./components/extrapages/PlayerTransferPoints";
import PlayerHistrory from "./components/extrapages/PlayerHistrory"; 
import TransactionReport from "./components/extrapages/TransactionReport";
import TurnOverReport from "./components/extrapages/TurnOverReport";
import ViewAgent from "./components/extrapages/ViewAgent";
import GameHistory from "./components/extrapages/GameHistory";
import ShowCurrentBet from "./components/extrapages/ShowCurrentBet";  
import CardsGame from "./components/extrapages/Betpage/CardsGame";
import DoubleChanceGame from "./components/extrapages/Betpage/DoubleChanceGame";
import JeetoJokerGame from "./components/extrapages/Betpage/JeetoJokerGame"; 
import useToken from './Auth/useToken';
import AddNewPlayer from "./components/extrapages/AddNewPlayer"; 
import PlayersList from "./components/extrapages/PlayersList"; 
function App() { 
  const { token, setToken } = useToken(); 
  if(!token) {
    return <Login setToken={setToken} />
  }
  
  return (
    <Router>
      <Switch>
        {/* <Route path="/login" exact component={Login} /> */}
        <Switch>
          <div className="App">
            <Dashboard />,
            <Route exact path="/" component={DashBody} />  
            <Route path="/AddPlayer" component={AddPlayer} /> 
            <Route path="/AddNewDistributor" component={CreateAgent} />
            <Route path="/DistributorList" component={ViewAgent} />
            <Route path="/AddnewPlayer" component={AddNewPlayer} />
            <Route path="/PlayersList" component={PlayersList} />
            <Route path="/SendPointsToDistributor" component={PlayerTransferPoints} />
            <Route path="/PoitsReportHistory" component={TransactionReport} />
            <Route path="/ShowCurrentBet" component={ShowCurrentBet} />
            <Route path="/JeetoJokerGame" component={DoubleChanceGame} />
            <Route path="/16CardsGame" component={CardsGame} />
            <Route path="/SpinWinGame" component={JeetoJokerGame} />
            <Route path="/TurnOverReport" component={TurnOverReport} /> 
            <Route path="/changepassword" component={ChangePassword} />
            <Route path="/updatedUserPassword" component={IdChangePassword} />
            <Route path="/PlayersHistrory" component={PlayerHistrory} />
            <Route path="/GamePlayHistory" component={GameHistory} /> 
            <Route path="*" component={() => ""} />
          </div>
        </Switch>
      </Switch>
    </Router>
  );
}

//guard

export default App;
